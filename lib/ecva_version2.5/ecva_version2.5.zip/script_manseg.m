% Script
% Example of how to make 4 manual segments for 50 samples

manualseg{1}=[1:15 41:50]';
manualseg{2}=[16:30]';
manualseg{3}=[31:40]';
